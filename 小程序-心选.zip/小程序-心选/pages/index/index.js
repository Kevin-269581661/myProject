//index.js
//获取应用实例
const app = getApp()

Page({

  /**
   * 页面的初始数据
   */
  data: {
    list:[
      {id:1,img_url:"/pages/image/banner01.jpg"},
      { id: 2, img_url: "/pages/image/banner02.jpg"},
      { id: 3, img_url: "/pages/image/banner03.jpg"},
      { id: 4, img_url: "/pages/image/banner04.jpg"}
    ],
    list2:[
      { id: 1, msg: "居家", img_url:"/pages/image/icon01.png"},
      { id: 2, msg: "鞋包配饰", img_url: "/pages/image/icon02.png" },
      { id: 3, msg: "服饰", img_url: "/pages/image/icon03.png" },
      { id: 4, msg: "电器", img_url: "/pages/image/icon04.png" },
      { id: 5, msg: "婴童", img_url: "/pages/image/icon05.png" },
      { id: 6, msg: "饮食", img_url: "/pages/image/icon06.png" },
      { id: 7, msg: "洗护", img_url: "/pages/image/icon07.png" },
      { id: 8, msg: "餐厨", img_url: "/pages/image/icon08.png" },
      { id: 9, msg: "文体", img_url: "/pages/image/icon09.png" },
      { id: 10, msg: "特色区", img_url: "/pages/image/icon10.png" }
    ]

  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
    
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
    
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
    
  }
})
