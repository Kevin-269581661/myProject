#小程序-心选小铺数据库xx
#创建数据库xz
SET NAMES UTF8;
DROP DATABASE IF EXISTS xx;
CREATE DATABASE xx CHARSET=UTF8;
#进入库  xx
USE xx;
#01. 轮播图表： xx_banner
CREATE TABLE xx_banner(
  id INT PRIMARY KEY AUTO_INCREMENT,
  img_url VARCHAR(255) COMMENT "轮播图url",
  pid INT COMMENT "对应商品编号"
);
INSERT INTO xx_banner VALUES
(null,"http://127.0.0.1:3030/img/banner/banner01.jpg",1),
(null,"http://127.0.0.1:3030/img/banner/banner02.jpg",2),
(null,"http://127.0.0.1:3030/img/banner/banner03.jpg",3),
(null,"http://127.0.0.1:3030/img/banner/banner04.jpg",4)

#02. 首页九宫格表： xx_gongge
CREATE TABLE xx_gongge(
  id INT PRIMARY KEY AUTO_INCREMENT,
  title VARCHAR(10) COMMENT "类名",
  img_url VARCHAR(255) COMMENT "图标的url",
  sid INT COMMENT "对应商品类别编号"
);
INSERT INTO xx_gongge VALUES
(null,"居家","http://127.0.0.1:3030/img/gongge/icon01.png",1),
(null,"鞋包配饰","http://127.0.0.1:3030/img/gongge/icon02.png",2),
(null,"服饰","http://127.0.0.1:3030/img/gongge/icon03.png",3),
(null,"电器","http://127.0.0.1:3030/img/gongge/icon04.png",4),
(null,"婴童","http://127.0.0.1:3030/img/gongge/icon05.png",5),
(null,"饮食","http://127.0.0.1:3030/img/gongge/icon06.png",6),
(null,"洗护","http://127.0.0.1:3030/img/gongge/icon07.png",7),
(null,"餐厨","http://127.0.0.1:3030/img/gongge/icon08.png",8),
(null,"文体","http://127.0.0.1:3030/img/gongge/icon09.png",9),
(null,"特色区","http://127.0.0.1:3030/img/gongge/icon10.png",10)

#03.首页楼层展示表： xx_floor
CREATE TABLE xx_floor(
  id INT PRIMARY KEY AUTO_INCREMENT,
  hotTitle VARCHAR(10) COMMENT "楼层左侧名称",
  hotImgUrl VARCHAR(255) COMMENT "楼层图的url",
  hotItemId INT COMMENT "商品滚动列表id"
);
INSERT INTO xx_gongge VALUES
(null,"热门推荐","http://127.0.0.1:3030/img/floor/hot01.jpg",1)
(null,"优选好货","http://127.0.0.1:3030/img/floor/hot02.jpg",2)

#04.首页楼层展示表=> 商品滚动列表：xx_hot
CREATE TABLE xx_hot(
  id INT PRIMARY KEY AUTO_INCREMENT,
  info VARCHAR(20) COMMENT "商品的介绍",
  img_url VARCHAR(255) COMMENT "商品图的url",
  mark VARCHAR(20) COMMENT "促销标签",
  price DECIMAL(10,2) COMMENT "价格",
  pid INT COMMENT "对应商品编号"
);
INSERT INTO xx_hot VALUES
(null,"美的智造T300无线吸尘器","http://127.0.0.1:3030/img/products/product01.png","家电特惠",15,1),
(null,"美国制造 除甲醛空气净化剂227g","http://127.0.0.1:3030/img/products/product02.png","家电特惠",15,2),
(null,"5件装 30包 古风一木四件套囤货清仓","http://127.0.0.1:3030/img/products/product03.png","家电特惠",15,3),
(null,"美的智造T300无线吸尘器","http://127.0.0.1:3030/img/products/product04.png","家电特惠",15,4),
(null,"美的智造T300无线吸尘器","http://127.0.0.1:3030/img/products/product05.png","家电特惠",15,5),
(null,"美的智造T300无线吸尘器","http://127.0.0.1:3030/img/products/product06.png","家电特惠",15,6)

#05首页商品推荐列表：xx_show
CREATE TABLE xx_show(
  id INT PRIMARY KEY AUTO_INCREMENT,
  title VARCHAR(50) COMMENT "商品名称",
  img_url VARCHAR(255) COMMENT "商品图的url",
  mark VARCHAR(20) COMMENT "促销标签",
  newPrice DECIMAL(10,2) COMMENT "现价",
  oldPrice DECIMAL(10,2) COMMENT "旧价",
  des VARCHAR(20) COMMENT "商品介绍",
  color VARCHAR(10) COMMENT "商品的颜色种类",
  pid INT COMMENT "对应商品编号"
);
INSERT INTO xx_show VALUES
(null,"冬季特暖棉绒袜","http://127.0.0.1:3030/img/products/product01.png","圣诞特惠",12,52,"保暖，舒适，质量好",8,1),
(null,"冬季特暖棉棉被","http://127.0.0.1:3030/img/products/product02.png","打折",56,92,"保暖，舒适，质量好",8,2),
(null,"家用按摩器","http://127.0.0.1:3030/img/products/product03.png","好货",92,152,"保暖，舒适，质量好",8,3),
(null,"冬季特暖棉绒袜1","http://127.0.0.1:3030/img/products/product04.png","圣诞特惠",12,52,"保暖，舒适，质量好",8,4),
(null,"冬季特暖棉绒袜2","http://127.0.0.1:3030/img/products/product05.png","圣诞特惠",12,52,"保暖，舒适，质量好",8,5),
(null,"冬季特暖棉绒袜3","http://127.0.0.1:3030/img/products/product06.png","圣诞特惠",12,52,"保暖，舒适，质量好",8,6),
(null,"冬季特暖棉绒袜4","http://127.0.0.1:3030/img/products/product07.png","圣诞特惠",12,52,"保暖，舒适，质量好",8,7),
(null,"冬季特暖棉绒袜5","http://127.0.0.1:3030/img/products/product01.png","圣诞特惠",12,52,"保暖，舒适，质量好",8,8),
(null,"冬季特暖棉绒袜6","http://127.0.0.1:3030/img/products/product02.png","圣诞特惠",12,52,"保暖，舒适，质量好",8,9),
(null,"冬季特暖棉绒袜7","http://127.0.0.1:3030/img/products/product03.png","圣诞特惠",12,52,"保暖，舒适，质量好",8,10),
(null,"冬季特暖棉绒袜8","http://127.0.0.1:3030/img/products/product04.png","圣诞特惠",12,52,"保暖，舒适，质量好",8,11),
(null,"冬季特暖棉绒袜9","http://127.0.0.1:3030/img/products/product05.png","圣诞特惠",12,52,"保暖，舒适，质量好",8,12),
(null,"冬季特暖棉绒袜10","http://127.0.0.1:3030/img/products/product06.png","圣诞特惠",12,52,"保暖，舒适，质量好",8,13)

#06分类页-商品类名表：xx_sorts
CREATE TABLE xx_sorts(
  id INT PRIMARY KEY AUTO_INCREMENT,
  title VARCHAR(50) COMMENT "类名称",
  stable VARCHAR(50) COMMENT "对应商品类别的表名"
);
INSERT INTO xx_sorts VALUES
(null,"冬季专区","pSort1"),
(null,"鞋包配饰","pSort2"),
(null,"服装","pSort3"),
(null,"电器","pSort4"),
(null,"洗护","pSort5"),
(null,"饮食","pSort6"),
(null,"餐厨","pSort7"),
(null,"婴童","pSort8"),
(null,"文体","pSort9"),
(null,"鞋包配饰","pSort10"),
(null,"冬季专区","pSort11"),
(null,"冬季专区","pSort12"),
(null,"冬季专区","pSort13"),
(null,"冬季专区","pSort14")

#07"冬季专区",pSort1 表：
CREATE TABLE xx_sorts(
  id INT PRIMARY KEY AUTO_INCREMENT,
  title VARCHAR(50) COMMENT "类名称",
  table VARCHAR(50) COMMENT "对应商品类别的表名"
);

#04.app首页新品推荐列表：xx_new_list
CREATE TABLE xx_new_list(
  id INT PRIMARY KEY AUTO_INCREMENT,
  img_url VARCHAR(255) COMMENT "商品图的url",
  title VARCHAR(20) COMMENT "商品名称",
  info VARCHAR(20) COMMENT "商品的介绍",
  price DECIMAL(10,2) COMMENT "价格",
  pid INT COMMENT "对应商品编号"
);
INSERT INTO xx_new_list VALUES
(null,"http://127.0.0.1:3030/img/products/product01.png","女式式舒适中筒袜","“优质棉绒，细腻平纹，百搭配色。”","45","1"),
(null,"http://127.0.0.1:3030/img/products/product02.png","百年传世珐琅锅 全家系列","“质量很好，方便清洗，简单烹饪。”","398","2"),
(null,"http://127.0.0.1:3030/img/products/product03.png","家用按摩器","“给工作之余，身体的最好呵护。”","125","3"),
(null,"http://127.0.0.1:3030/img/products/product04.png","可爱软萌抱枕","“颜色多样，采用棉绒材质。”","465","4"),
(null,"http://127.0.0.1:3030/img/products/product05.png","西班牙制造 高端按摩椅","“海外精品，质量有保证。”","2546","5"),
(null,"http://127.0.0.1:3030/img/products/product06.png","精致简约 苹果无线鼠标","“独特设计，手感很舒适。”","155","6"),
(null,"http://127.0.0.1:3030/img/products/product07.png","家用清洁器 电动清扫","“打扫房间不再是一件麻烦事。”","275","7")





#05用户信息表：xx_user
CREATE TABLE xx_user(
  id INT PRIMARY KEY AUTO_INCREMENT,
  uname VARCHAR(50) COMMENT "用户名",
  upwd VARCHAR(50) COMMENT "密码",
  email VARCHAR(50) COMMENT "邮箱",
  avatar VARCHAR(255) DEFAULT "http://127.0.0.1:3030/img/person/person01.png" COMMENT "头像url"
);

#用户购物车表：xx_cart
CREATE TABLE xx_cart(
  id INT PRIMARY KEY AUTO_INCREMENT,
  user_id INT COMMENT "用户id",
  product_id INT COMMENT "商品id",
  count INT COMMENT "商品数量",
  title VARCHAR(50) COMMENT "商品名称",
  img_url VARCHAR(255) COMMENT "商品主图url",
  mark VARCHAR(150) COMMENT "促销标签",
  is_checked VARCHAR(10) DEFAULT 1 COMMENT "是否选中", #0未选中 1选中 
  sort_id INT COMMENT "商品规格id"
);

#05商品表：xx_products
CREATE TABLE xx_products(
  id INT PRIMARY KEY AUTO_INCREMENT,
  banner VARCHAR(900) COMMENT "轮播图",
  title VARCHAR(60) COMMENT "商品名称",
  sub_title VARCHAR(60) COMMENT "商品副标题",
  mark VARCHAR(20) COMMENT "促销标签",
  size_normal VARCHAR(500) COMMENT "商品副规格",  #普通属性(集合)，不影响价格的商品的其他属性
  color_count INT DEFAULT 1 COMMENT "几种颜色"
);
INSERT INTO xx_products VALUES
(null,"http://127.0.0.1:3030/img/details/p03-d03.jpg|http://127.0.0.1:3030/img/details/p03-d01.jpg|http://127.0.0.1:3030/img/details/p03-d02.jpg|http://127.0.0.1:3030/img/details/p03-d04.jpg","男式真皮休闲夹克1","儒雅风度，小羊皮的真实质感","特价|元旦优惠",null,4),
(null,"http://127.0.0.1:3030/img/details/product02-detail01.png|http://127.0.0.1:3030/img/details/product02-detail02.png","家用按摩器2","给工作之余，身体的最好呵护",null,null,DEFAULT),
(null,"http://127.0.0.1:3030/img/details/product-detail-banner01.jpg|http://127.0.0.1:3030/img/details/product-detail-banner02.jpg|http://127.0.0.1:3030/img/details/product-detail-banner03.jpg|http://127.0.0.1:3030/img/details/product-detail-banner04.jpg","女式式舒适中筒袜3","优质棉绒，细腻平纹，百搭配色","新品上架",null,5),
(null,"http://127.0.0.1:3030/img/details/p03-d03.jpg|http://127.0.0.1:3030/img/details/p03-d01.jpg|http://127.0.0.1:3030/img/details/p03-d02.jpg|http://127.0.0.1:3030/img/details/p03-d04.jpg","男式真皮休闲夹克4","儒雅风度，小羊皮的真实质感","特价|元旦优惠",null,2),
(null,"http://127.0.0.1:3030/img/details/product02-detail01.png|http://127.0.0.1:3030/img/details/product02-detail02.png","家用按摩器5","给工作之余，身体的最好呵护",null,null,DEFAULT),
(null,"http://127.0.0.1:3030/img/details/product-detail-banner01.jpg|http://127.0.0.1:3030/img/details/product-detail-banner02.jpg|http://127.0.0.1:3030/img/details/product-detail-banner03.jpg|http://127.0.0.1:3030/img/details/product-detail-banner04.jpg","女式式舒适中筒袜6","优质棉绒，细腻平纹，百搭配色","新品上架",null,DEFAULT),
(null,"http://127.0.0.1:3030/img/details/p03-d03.jpg|http://127.0.0.1:3030/img/details/p03-d01.jpg|http://127.0.0.1:3030/img/details/p03-d02.jpg|http://127.0.0.1:3030/img/details/p03-d04.jpg","男式真皮休闲夹克7","儒雅风度，小羊皮的真实质感","特价|元旦优惠",null,2),
(null,"http://127.0.0.1:3030/img/details/product02-detail01.png|http://127.0.0.1:3030/img/details/product02-detail02.png","家用按摩器8","给工作之余，身体的最好呵护",null,null,DEFAULT),
(null,"http://127.0.0.1:3030/img/details/product-detail-banner01.jpg|http://127.0.0.1:3030/img/details/product-detail-banner02.jpg|http://127.0.0.1:3030/img/details/product-detail-banner03.jpg|http://127.0.0.1:3030/img/details/product-detail-banner04.jpg","女式式舒适中筒袜9","优质棉绒，细腻平纹，百搭配色","新品上架",null,6),
(null,"http://127.0.0.1:3030/img/details/p03-d03.jpg|http://127.0.0.1:3030/img/details/p03-d01.jpg|http://127.0.0.1:3030/img/details/p03-d02.jpg|http://127.0.0.1:3030/img/details/p03-d04.jpg","男式真皮休闲夹克10","儒雅风度，小羊皮的真实质感","特价|元旦优惠",null,DEFAULT),
(null,"http://127.0.0.1:3030/img/details/product02-detail01.png|http://127.0.0.1:3030/img/details/product02-detail02.png","家用按摩器11","给工作之余，身体的最好呵护",null,null,4),
(null,"http://127.0.0.1:3030/img/details/product-detail-banner01.jpg|http://127.0.0.1:3030/img/details/product-detail-banner02.jpg|http://127.0.0.1:3030/img/details/product-detail-banner03.jpg|http://127.0.0.1:3030/img/details/product-detail-banner04.jpg","女式式舒适中筒袜12","优质棉绒，细腻平纹，百搭配色","新品上架",null,DEFAULT)

INSERT INTO xx_products VALUES
(null,"http://127.0.0.1:3030/img/details/p03-d03.jpg|http://127.0.0.1:3030/img/details/p03-d01.jpg|http://127.0.0.1:3030/img/details/p03-d02.jpg|http://127.0.0.1:3030/img/details/p03-d04.jpg","男式真皮休闲夹克13","儒雅风度，小羊皮的真实质感","特价|元旦优惠",null,4),
(null,"http://127.0.0.1:3030/img/details/product02-detail01.png|http://127.0.0.1:3030/img/details/product02-detail02.png","家用按摩器14","给工作之余，身体的最好呵护",null,null,DEFAULT),
(null,"http://127.0.0.1:3030/img/details/product-detail-banner01.jpg|http://127.0.0.1:3030/img/details/product-detail-banner02.jpg|http://127.0.0.1:3030/img/details/product-detail-banner03.jpg|http://127.0.0.1:3030/img/details/product-detail-banner04.jpg","女式式舒适中筒袜15","优质棉绒，细腻平纹，百搭配色","新品上架",null,5),
(null,"http://127.0.0.1:3030/img/details/p03-d03.jpg|http://127.0.0.1:3030/img/details/p03-d01.jpg|http://127.0.0.1:3030/img/details/p03-d02.jpg|http://127.0.0.1:3030/img/details/p03-d04.jpg","男式真皮休闲夹克16","儒雅风度，小羊皮的真实质感","特价|元旦优惠",null,2),
(null,"http://127.0.0.1:3030/img/details/product02-detail01.png|http://127.0.0.1:3030/img/details/product02-detail02.png","家用按摩器17","给工作之余，身体的最好呵护",null,null,DEFAULT),
(null,"http://127.0.0.1:3030/img/details/product-detail-banner01.jpg|http://127.0.0.1:3030/img/details/product-detail-banner02.jpg|http://127.0.0.1:3030/img/details/product-detail-banner03.jpg|http://127.0.0.1:3030/img/details/product-detail-banner04.jpg","女式式舒适中筒袜17","优质棉绒，细腻平纹，百搭配色","新品上架",null,DEFAULT),
(null,"http://127.0.0.1:3030/img/details/p03-d03.jpg|http://127.0.0.1:3030/img/details/p03-d01.jpg|http://127.0.0.1:3030/img/details/p03-d02.jpg|http://127.0.0.1:3030/img/details/p03-d04.jpg","男式真皮休闲夹克19","儒雅风度，小羊皮的真实质感","特价|元旦优惠",null,2),
(null,"http://127.0.0.1:3030/img/details/product02-detail01.png|http://127.0.0.1:3030/img/details/product02-detail02.png","家用按摩器20","给工作之余，身体的最好呵护",null,null,DEFAULT),
(null,"http://127.0.0.1:3030/img/details/product-detail-banner01.jpg|http://127.0.0.1:3030/img/details/product-detail-banner02.jpg|http://127.0.0.1:3030/img/details/product-detail-banner03.jpg|http://127.0.0.1:3030/img/details/product-detail-banner04.jpg","女式式舒适中筒袜21","优质棉绒，细腻平纹，百搭配色","新品上架",null,6),
(null,"http://127.0.0.1:3030/img/details/p03-d03.jpg|http://127.0.0.1:3030/img/details/p03-d01.jpg|http://127.0.0.1:3030/img/details/p03-d02.jpg|http://127.0.0.1:3030/img/details/p03-d04.jpg","男式真皮休闲夹克22","儒雅风度，小羊皮的真实质感","特价|元旦优惠",null,DEFAULT),
(null,"http://127.0.0.1:3030/img/details/product02-detail01.png|http://127.0.0.1:3030/img/details/product02-detail02.png","家用按摩器23","给工作之余，身体的最好呵护",null,null,4),
(null,"http://127.0.0.1:3030/img/details/product-detail-banner01.jpg|http://127.0.0.1:3030/img/details/product-detail-banner02.jpg|http://127.0.0.1:3030/img/details/product-detail-banner03.jpg|http://127.0.0.1:3030/img/details/product-detail-banner04.jpg","女式式舒适中筒袜24","优质棉绒，细腻平纹，百搭配色","新品上架",null,DEFAULT)


#商品规格表：xx_product_size
CREATE TABLE xx_product_size(
  id INT PRIMARY KEY AUTO_INCREMENT, 
  size_main VARCHAR(50) COMMENT "主规格",  #单一属性影响商品其他的属性，如价格，尺寸
  size_sub VARCHAR(500) COMMENT "副规格",  #主规格对应属性，如商品颜色对应尺码（集合）
  img_url VARCHAR(255) COMMENT "商品图片url",
  new_price DECIMAL(10,2) COMMENT "现价",
  old_price DECIMAL(10) COMMENT "原价",
  product_id INT COMMENT "商品id"
);
INSERT INTO xx_product_size VALUES
(null,""),

#商品颜色对应尺码表：xx_color_size
CREATE TABLE xx_color_size(
  id INT PRIMARY KEY AUTO_INCREMENT,
  product_color VARCHAR(500) COMMENT "商品颜色",
  size_price VARCHAR(500) COMMENT "商品主规格",  #影响商品的属性
  img_url VARCHAR(255) COMMENT "商品图片url",
  new_price DECIMAL(10,2) COMMENT "现价",
  old_price DECIMAL(10) COMMENT "原价",
  product_id INT COMMENT "商品id"
);



CREATE TABLE xx_banner(
  id INT PRIMARY KEY AUTO_INCREMENT,
  title VARCHAR(50)  ,
  ctime DATETIME,
  point INT,
  img_url VARCHAR(255) COMMENT "轮播图url",
  content VARCHAR(255) 
);
INSERT INTO xz_news VALUES(1,'123',now(),0,
"http://127.0.0.1:3000/img/1.jpg","..");
INSERT INTO xz_news VALUES(2,'124',now(),0,
"http://127.0.0.1:3000/img/1.jpg","..");
INSERT INTO xz_news VALUES(3,'1233',now(),0,
"http://127.0.0.1:3000/img/1.jpg","..");
INSERT INTO xz_news VALUES(4,'124',now(),0,
"http://127.0.0.1:3000/img/1.jpg","..");
INSERT INTO xz_news VALUES(5,'125',now(),0,
"http://127.0.0.1:3000/img/1.jpg","..");
INSERT INTO xz_news VALUES(6,'126',now(),0,
"http://127.0.0.1:3000/img/1.jpg","..");
INSERT INTO xz_news VALUES(7,'127',now(),0,
"http://127.0.0.1:3000/img/1.jpg","..");
INSERT INTO xz_news VALUES(8,'128',now(),0,
"http://127.0.0.1:3000/img/1.jpg","..");
INSERT INTO xz_news VALUES(9,'129',now(),0,
"http://127.0.0.1:3000/img/1.jpg","..");
INSERT INTO xz_news VALUES(11,'1231',now(),0,
"http://127.0.0.1:3000/img/1.jpg","..");
INSERT INTO xz_news VALUES(12,'1232',now(),0,
"http://127.0.0.1:3000/img/1.jpg","..");
INSERT INTO xz_news VALUES(13,'1233',now(),0,
"http://127.0.0.1:3000/img/1.jpg","..");
INSERT INTO xz_news VALUES(14,'1234',now(),0,
"http://127.0.0.1:3000/img/1.jpg","..");
INSERT INTO xz_news VALUES(15,'1235',now(),0,
"http://127.0.0.1:3000/img/1.jpg","..");
INSERT INTO xz_news VALUES(16,'1236',now(),0,
"http://127.0.0.1:3000/img/1.jpg","..");
INSERT INTO xz_news VALUES(17,'1237',now(),0,
"http://127.0.0.1:3000/img/1.jpg","..");
INSERT INTO xz_news VALUES(18,'1238',now(),0,
"http://127.0.0.1:3000/img/1.jpg","..");
INSERT INTO xz_news VALUES(19,'1239',now(),0,
"http://127.0.0.1:3000/img/1.jpg","..");
INSERT INTO xz_news VALUES(21,'12322',now(),0,
"http://127.0.0.1:3000/img/1.jpg","..");
INSERT INTO xz_news VALUES(22,'12322',now(),0,
"http://127.0.0.1:3000/img/1.jpg","..");

#货币 小数计算误差
#价格 购物车合计 
#double DECIMAL(10,2)
#严格   将货币转换分单位  1.99 -> 199
#显示  1.99
#3:添加20条记录
#4:查询

#1:创建评论表 39
#   表名 几列 列名
#   xz_comment
#   id        INT        评论编号
#   nid       INT        评论所属新闻编号
#   user_name VARCHAR(25)评论人名称
#   ctime     DATETIME   时间
#   content   VARCHAR(120)内容

USE xz;
CREATE TABLE xz_comment(
  id INT PRIMARY KEY AUTO_INCREMENT,
  nid INT,
  user_name VARCHAR(25),
  ctime DATETIME,
  content VARCHAR(120)
);
#2:添加15条
INSERT INTO xz_comment VALUES(null,1,'dd',now(),'111');
INSERT INTO xz_comment VALUES(null,1,'dd',now(),'112');
INSERT INTO xz_comment VALUES(null,1,'dd',now(),'113');
INSERT INTO xz_comment VALUES(null,1,'dd',now(),'114');
INSERT INTO xz_comment VALUES(null,1,'dd',now(),'115');
INSERT INTO xz_comment VALUES(null,1,'dd',now(),'116');
INSERT INTO xz_comment VALUES(null,1,'dd',now(),'117');
INSERT INTO xz_comment VALUES(null,1,'dd',now(),'118');
INSERT INTO xz_comment VALUES(null,1,'dd',now(),'119');
INSERT INTO xz_comment VALUES(null,1,'dd',now(),'1110');
INSERT INTO xz_comment VALUES(null,1,'dd',now(),'1111');
INSERT INTO xz_comment VALUES(null,1,'dd',now(),'1112');
INSERT INTO xz_comment VALUES(null,1,'dd',now(),'1113');
INSERT INTO xz_comment VALUES(null,1,'dd',now(),'1114');
INSERT INTO xz_comment VALUES(null,1,'dd',now(),'1115');
INSERT INTO xz_comment VALUES(null,1,'dd',now(),'1116');

CREATE TABLE xz_login(
  id INT PRIMARY KEY AUTO_INCREMENT,
  uname VARCHAR(25) NOT NULL DEFAULT '',
  upwd  VARCHAR(32) NOT NULL DEFAULT ''
);
INSERT INTO xz_login VALUES(null,'dd',md5('123'));
INSERT INTO xz_login VALUES(null,'tom',md5('123'));
INSERT INTO xz_login VALUES(null,'jerry',md5('123'));



