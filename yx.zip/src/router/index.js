import Vue from 'vue'
import Router from 'vue-router'
import HelloWorld from '@/components/HelloWorld'

import Home from '../components/Home.vue'
import Test from '../components/test.vue'
import ProductList from '../components/ProductList.vue'
import Details from '../components/Details.vue'

Vue.use(Router)

export default new Router({
  routes: [
    {path: '/',redirect: '/home'},
    {path:'/home',component:Home},
    {path:'/test',component:Test},
    {path:'/productlist',component:ProductList},
    {path:'/details',component:Details}
  ]
})
