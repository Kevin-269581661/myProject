// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.
import Vue from 'vue'
import App from './App'
import router from './router'
//引入组件库样式文件
import 'swiper/dist/css/swiper.css'
import 'mint-ui/lib/style.css'
import './lib/mui/css/icons-extra.css'
import './lib/mui/css/mui.css'
//引入字体图标样式
import '../static/icon-font/iconfont.css'
//引入mint-ui组件
import { TabContainer, TabContainerItem,Button,Cell,Swipe,SwipeItem,Navbar,TabItem } from 'mint-ui'
//注册组件
Vue.component(TabContainer.name, TabContainer);
Vue.component(TabContainerItem.name, TabContainerItem);
Vue.component(Button.name,Button);
Vue.component(Cell.name,Cell);
Vue.component(Swipe.name,Swipe);
Vue.component(SwipeItem.name,SwipeItem);
Vue.component(Navbar.name,Navbar);
Vue.component(TabItem.name,TabItem);

// 引入swiper组件库

Vue.config.productionTip = false

/* eslint-disable no-new */
new Vue({
  el: '#app',
  router,
  components: { App },
  template: '<App/>'
})
