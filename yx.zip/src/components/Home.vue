<template>
  <div>
    <!-- 引入头部子组件 -->
    <my-header></my-header>
    <!-- 顶部导航 -->
    <div>
      <div class="view-swiper">
        <div class="nav-con">
          <mt-navbar v-model="selected">
            <mt-tab-item id="tab1">推荐</mt-tab-item>
            <mt-tab-item id="tab2">新品</mt-tab-item>
            <mt-tab-item id="tab3">福利社</mt-tab-item>
            <mt-tab-item id="tab4">限时购</mt-tab-item>
            <mt-tab-item id="tab5">居家</mt-tab-item>
            <mt-tab-item id="tab6">鞋包配饰</mt-tab-item>
            <mt-tab-item id="tab7">服装</mt-tab-item>
            <mt-tab-item id="tab8">电器</mt-tab-item>
            <mt-tab-item id="tab9">洗护</mt-tab-item>
          </mt-navbar>
        </div>
      </div>
      
     
      <!-- <div class="swiper-container" id="swiper1">
        <ul class="swiper-wrapper navbar">
          <li class="swiper-slide tab" v-for="(val,key,index) in tabs" :key="index"  @touchstart="selected = key;n = index" :class="index == n ? 'act':''">{{val}}</li>
        </ul>
      </div> -->
      
      <!-- <ul class="nav">
        <li v-for="(item,index) in tabs" :key="index"  @touchstart.prevent="active = item.id;n = index" :class="index == n ? 'act':''">{{item.title}}</li>
      </ul> -->
      <div class="page-tab-container">
        <mt-tab-container class="page-tabbar-tab-container" v-model="selected" swipeable>
          <mt-tab-container-item id="tab1">
            <!-- 引入轮播子组件 -->
            <div>
              <swiper-box :list="list"></swiper-box>
            </div>
            <!-- 商家承诺 -->
            <div class="promise">
              <div>
                <span class="iconfont icon-wancheng"></span>自营品牌
              </div>
              <div>
                <span class="iconfont icon-wancheng"></span>30天无忧退换货
              </div>
              <div>
                <span class="iconfont icon-wancheng"></span>48小时快速退款
              </div>
            </div>
            <!-- 九宫格 -->
            <div class="pro-sort">
              <div class="sort-item" v-for="(item,index) in sortList" :key="index" >
                <img :src="item.img_url" :alt="item.id">
                <div>{{item.title}}</div>
              </div>
            </div>
            <!-- 分隔条 -->
            <div class="split"></div>
            <!-- 商品推荐 -->
            <div class="new-pro">
              <div class="new-title">新品推荐</div>
              <div class="new-top">
                <div class="new-top-left">
                  <img src="http://127.0.0.1:3030/img/products/product01.png" alt="">
                </div>
                <div class="new-top-right">
                  <div class="new-top-title ell">西班牙制造 质量超好的袜子</div>
                  <div class="new-top-price">¥28</div>
                  <div class="new-top-info">“质量没得说，穿着很舒适，非常贴近皮肤”</div>
                </div>
              </div>
              <div class="new-content">
                <div class="new-item">
                  <div class="item-img">
                    <img src="http://127.0.0.1:3030/img/products/product02.png" alt="">
                  </div>
                  <div class="item-bottom">
                    <div class="item-title">
                    西班牙制造 质量超好的袜子
                    <span class="item-price">¥28</span>
                    </div>
                    <div class="split-hr"></div>
                    <div class="item-info">“质量没得说，穿着很舒适。”</div>
                  </div>
                </div>
                <div class="new-item">
                  <div class="item-img">
                    <img src="http://127.0.0.1:3030/img/products/product02.png" alt="">
                  </div>
                  <div class="item-bottom">
                    <div class="item-title">
                    西班牙制造 质量超好的袜子
                    <span class="item-price">¥28</span>
                    </div>
                    <div class="split-hr"></div>
                    <div class="item-info">“质量没得说，穿着很舒适。”</div>
                  </div>
                </div>
                <div class="new-item">
                  <div class="item-img">
                    <img src="http://127.0.0.1:3030/img/products/product02.png" alt="">
                  </div>
                  <div class="item-bottom">
                    <div class="item-title">
                    西班牙制造 质量超好的袜子
                    <span class="item-price">¥28</span>
                    </div>
                    <div class="split-hr"></div>
                    <div class="item-info">“质量没得说，穿着很舒适。”</div>
                  </div>
                </div>
                <div class="new-item">
                  <div class="item-img">
                    <img src="http://127.0.0.1:3030/img/products/product02.png" alt="">
                  </div>
                  <div class="item-bottom">
                    <div class="item-title">
                    西班牙制造 质量超好的袜子
                    <span class="item-price">¥28</span>
                    </div>
                    <div class="split-hr"></div>
                    <div class="item-info">“质量没得说，穿着很舒适。”</div>
                  </div>
                </div>
                <div class="new-item">
                  <div class="item-img">
                    <img src="http://127.0.0.1:3030/img/products/product02.png" alt="">
                  </div>
                  <div class="item-bottom">
                    <div class="item-title">
                    西班牙制造 质量超好的袜子
                    <span class="item-price">¥28</span>
                    </div>
                    <div class="split-hr"></div>
                    <div class="item-info">“质量没得说，穿着很舒适。”</div>
                  </div>
                </div>
                <div class="new-item">
                  <div class="item-img">
                    <img src="http://127.0.0.1:3030/img/products/product02.png" alt="">
                  </div>
                  <div class="item-bottom">
                    <div class="item-title">
                    西班牙制造 质量超好的袜子
                    <span class="item-price">¥28</span>
                    </div>
                    <div class="split-hr"></div>
                    <div class="item-info">“质量没得说，穿着很舒适。”</div>
                  </div>
                </div>
              </div>
            </div>
            <!-- 分隔条 -->
            <div class="split"></div>
            <!-- 人气推荐 -->
            <div class="hot-pro">
              <div class="hot-title">
                <div class="hot-title-left">人气推荐</div>
                <div class="hot-title-right">
                  更多
                  <i class="iconfont icon-xiangyoujiantou"></i>
                </div>
              </div>
              <div class="hot-top">
                <div class="hot-top-left">
                  <img src="http://127.0.0.1:3030/img/app-hot/hot01.jpg" alt="">
                </div>
                <div class="hot-top-right">
                  <div class="hot-top-title ell">全棉针织条纹四件套 新款</div>
                  <div class="hot-top-info">超柔针织棉，亲肤可裸睡</div>
                  <div class="hot-top-price">¥288</div>
                </div>
              </div>
              <!-- 修改为swiper -->
              <div class="swiper-container" id="swiper2">
                <div class="swiper-wrapper">
                  <div class="swiper-slide hot-item" >
                    <div class="hot-item-top">
                      <img src="http://127.0.0.1:3030/img/products/product03.png" alt="">
                      <div class="select-color">
                        <div>2</div>
                        <div>色</div>
                        <div>可</div>
                        <div>选</div>
                      </div>
                    </div>
                    <div class="hot-item-title">
                      升级款秋冬加厚，质量非常好
                      <span class="hot-item-price">¥288</span>
                    </div>
                    <div>
                      <div class="mark"><span>三石福利价</span></div>
                    </div>
                  </div>
                  <div class="swiper-slide hot-item" >
                    <div class="hot-item-top">
                      <img src="http://127.0.0.1:3030/img/products/product03.png" alt="">
                      <div class="select-color">
                        <div>2</div>
                        <div>色</div>
                        <div>可</div>
                        <div>选</div>
                      </div>
                    </div>
                    <div class="hot-item-title">
                      升级款秋冬加厚，质量非常好
                      <span class="hot-item-price">¥288</span>
                    </div>
                    <div>
                      <div class="mark"><span>三石福利价</span></div>
                    </div>
                  </div>
                  <div class="swiper-slide hot-item" >
                    <div class="hot-item-top">
                      <img src="http://127.0.0.1:3030/img/products/product03.png" alt="">
                      <div class="select-color">
                        <div>2</div>
                        <div>色</div>
                        <div>可</div>
                        <div>选</div>
                      </div>
                    </div>
                    <div class="hot-item-title">
                      升级款秋冬加厚，质量非常好
                      <span class="hot-item-price">¥288</span>
                    </div>
                    <div>
                      <div class="mark"><span>三石福利价</span></div>
                    </div>
                  </div>
                  <div class="swiper-slide hot-item" >
                    <div class="hot-item-top">
                      <img src="http://127.0.0.1:3030/img/products/product03.png" alt="">
                      <div class="select-color">
                        <div>2</div>
                        <div>色</div>
                        <div>可</div>
                        <div>选</div>
                      </div>
                    </div>
                    <div class="hot-item-title">
                      升级款秋冬加厚，质量非常好
                      <span class="hot-item-price">¥288</span>
                    </div>
                    <div>
                      <div class="mark"><span>三石福利价</span></div>
                    </div>
                  </div>
                  <div class="swiper-slide hot-item" >
                    <div class="hot-item-top">
                      <img src="http://127.0.0.1:3030/img/products/product03.png" alt="">
                      <div class="select-color">
                        <div>2</div>
                        <div>色</div>
                        <div>可</div>
                        <div>选</div>
                      </div>
                    </div>
                    <div class="hot-item-title">
                      升级款秋冬加厚，质量非常好
                      <span class="hot-item-price">¥288</span>
                    </div>
                    <div>
                      <div class="mark"><span>三石福利价</span></div>
                    </div>
                  </div>
                  <div class="swiper-slide hot-item" >
                    <div class="hot-item-top">
                      <img src="http://127.0.0.1:3030/img/products/product03.png" alt="">
                      <div class="select-color">
                        <div>2</div>
                        <div>色</div>
                        <div>可</div>
                        <div>选</div>
                      </div>
                    </div>
                    <div class="hot-item-title">
                      升级款秋冬加厚，质量非常好
                      <span class="hot-item-price">¥288</span>
                    </div>
                    <div>
                      <div class="mark"><span>三石福利价</span></div>
                    </div>
                  </div>
                  <div class="swiper-slide hot-item" >
                    <div class="hot-item-top">
                      <img src="http://127.0.0.1:3030/img/products/product03.png" alt="">
                      <div class="select-color">
                        <div>2</div>
                        <div>色</div>
                        <div>可</div>
                        <div>选</div>
                      </div>
                    </div>
                    <div class="hot-item-title">
                      升级款秋冬加厚，质量非常好
                      <span class="hot-item-price">¥288</span>
                    </div>
                    <div>
                      <div class="mark"><span>三石福利价</span></div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </mt-tab-container-item>
          <mt-tab-container-item id="tab2">
            <!-- cell组件 -->
            <mt-cell v-for="n in 5" :key="n" title="tab-container 2"></mt-cell>
          </mt-tab-container-item>
          <mt-tab-container-item id="tab3">
            <!-- cell组件 -->
            <mt-cell v-for="n in 7" :key="n" title="tab-container 3"></mt-cell>
          </mt-tab-container-item>
          <mt-tab-container-item id="tab4">
            <!-- cell组件 -->
            <mt-cell v-for="n in 5" :key="n" title="tab-container 2"></mt-cell>
          </mt-tab-container-item>
          <mt-tab-container-item id="tab5">
            <!-- cell组件 -->
            <mt-cell v-for="n in 7" :key="n" title="tab-container 3"></mt-cell>
          </mt-tab-container-item>
          <mt-tab-container-item id="tab6">
            <!-- cell组件 -->
            <mt-cell v-for="n in 5" :key="n" title="tab-container 2"></mt-cell>
          </mt-tab-container-item>
          <mt-tab-container-item id="tab7">
            <!-- cell组件 -->
            <mt-cell v-for="n in 7" :key="n" title="tab-container 3"></mt-cell>
          </mt-tab-container-item>
          <mt-tab-container-item id="tab8">
            <!-- cell组件 -->
            <mt-cell v-for="n in 5" :key="n" title="tab-container 2"></mt-cell>
          </mt-tab-container-item>
          <mt-tab-container-item id="tab9">
            <!-- cell组件 -->
            <mt-cell v-for="n in 7" :key="n" title="tab-container 3"></mt-cell>
          </mt-tab-container-item>
        </mt-tab-container>
      </div>
    </div>
    <div class="footer"></div>
  </div>
</template>
<script>
import Header from './Header/header.vue'
import swipe from './sub/swipe.vue'
import Swiper from 'swiper';
export default {
  data(){
    return{
      //顶部导航
      selected: 'tab1',
      n:0,
      tabs:{
        tab1:"推荐",
        tab2:"新品",
        tab3:"福利社",
        tab4:"限时购",
        tab5:"居家",
        tab6:"鞋包配饰",
        tab7:"电器",
        tab8:"洗护",
        tab9:"服装"  
      },
      //轮播图列表
      list:[
        {id:1,img_url:"http://127.0.0.1:3030/img/banner/banner01.jpg"},
        {id:2,img_url:"http://127.0.0.1:3030/img/banner/banner02.jpg"},
        {id:3,img_url:"http://127.0.0.1:3030/img/banner/banner03.jpg"},
        {id:4,img_url:"http://127.0.0.1:3030/img/banner/banner04.jpg"},
      ],
      sortList:[
        {"id":1,"title":"居家","img_url":"http://127.0.0.1:3030/img/gongge/icon01.png","sid":1},
        {"id":2,"title":"鞋包配饰","img_url":"http://127.0.0.1:3030/img/gongge/icon02.png","sid":2},
        {"id":3,"title":"服饰","img_url":"http://127.0.0.1:3030/img/gongge/icon03.png","sid":3},
        {"id":4,"title":"电器","img_url":"http://127.0.0.1:3030/img/gongge/icon04.png","sid":4},
        {"id":5,"title":"婴童","img_url":"http://127.0.0.1:3030/img/gongge/icon05.png","sid":5},
        {"id":6,"title":"饮食","img_url":"http://127.0.0.1:3030/img/gongge/icon06.png","sid":6},
        {"id":7,"title":"洗护","img_url":"http://127.0.0.1:3030/img/gongge/icon07.png","sid":7},
        {"id":8,"title":"餐厨","img_url":"http://127.0.0.1:3030/img/gongge/icon08.png","sid":8},
        {"id":9,"title":"文体","img_url":"http://127.0.0.1:3030/img/gongge/icon09.png","sid":9},
        {"id":10,"title":"特色区","img_url":"http://127.0.0.1:3030/img/gongge/icon10.png","sid":10}
      ]
     
    }
  },
  methods: {
    handle(key,index){
      this.selected = key;
      this.n = index
    }
  },
  components:{
    "my-header":Header,
    "swiper-box":swipe
  },
  mounted() {
    new Swiper ('#swiper2', {
      direction: 'horizontal', // 垂直切换选项
      slidesPerView : 3,  //同时显示的slides数量
      spaceBetween : 10,  //在slide之间设置距离（单位px）
      freeMode : true,  //自由滑动
      touchMoveStopPropagation : true  //阻止冒泡
    }),
    new Swiper ('#swiper1', {
      freeMode : true,
      touchMoveStopPropagation : true,
      slidesPerView : 'auto',
      freeModeSticky:true,  //滑动停止时自动贴合边缘
      watchSlidesProgress:true,
      watchSlidesVisibility:true,
      on: {
        touchStart: ()=>{
          
        }
      }
    })
  },
}
</script>
<style >
  .navbar{
    background-color:#fff;
    height:0.4rem;
    border-bottom:1px solid #D9D9D9;
    box-sizing: border-box;
    padding-top:0.08rem;
  }
  .navbar .tab{
    display: inline-block !important;
    width: auto;  /* 必须要加这个宽度属性，否则li独占一行 */
    height:0.32rem;
    line-height:0.32rem;
    padding:0 0.1rem ;
    box-sizing:border-box;
    color:#1F1F1F;
    margin:0 2px;
    font-size: 0.15rem;
  }
  .act{
    color:#AD151B !important;
    border-bottom:2px solid #AD151B !important;
  }
  .view-swiper{
    height: 0.4rem;
    overflow: hidden;
  }
  .nav-con{
    overflow:scroll;
    white-space: nowrap;
    height: 1rem;
  }
  .mint-navbar .mint-tab-item.is-selected{
    color:#AD151B !important;
    border-bottom:2px solid #AD151B !important;
  }
  .mint-tab-item{
    flex: none !important;
    display: inline-block;
    height:0.32rem;
    line-height:0.32rem !important;
    padding:0 0.1rem !important;
    box-sizing:border-box;
    color:#1F1F1F;
    margin:0 2px;
  }
  .mint-navbar{
    display: block !important;
    background-color:#fff;
    height:0.4rem;
    border-bottom:1px solid #D9D9D9;
    box-sizing: border-box;
    padding-top:0.08rem;
  }
  .mint-tab-item .mint-tab-item-label{
    line-height:0.32rem !important;
    font-size: 0.15rem; 
  }
  .icon-wancheng{
    color:#B4282D;
  }
  .promise{
    display: flex;
    justify-content: space-between;
    color:#B4282D;
    font-size:0.12rem;
    height:0.32rem;
    line-height: 0.32rem;
    vertical-align: middle;
    background-color:#fff;
    padding: 0 0.1rem;
  }
  .icon-wancheng{
    margin:0.05rem 0.05rem 0 0 ;
    font-size:0.12rem;
  }
  .pro-sort{
    background-color:#fff;
    display: flex;
    flex-flow: row wrap;
  }
  .sort-item{
    font-size: 0.13rem;
    color:#343434;
    width:20%;
    padding:0.05rem 0;
    text-align: center;
  }
  .sort-item img{
    width:80%;
    margin-bottom: 0.05rem;
  }
  .split{
    height:0.1rem;
    background-color:#F4F4F4;
  }
  /* 新品推荐 */
  .new-pro{
    padding: 0 0.15rem;
  }
  .new-title{
    text-align: center;
    font-size: 0.16rem;
    color:#333;
    background-color: #fff;
    height:0.5rem;
    line-height: 0.5rem;
  }
  .new-top{
    display: flex;
    align-items: center;
    padding: 0.2rem 0.15rem;
    background-color: #F5F5F5;
    height:1.45rem;
    border-radius: 0.05rem;
  }
  .new-top-left{
    width:30%;
    margin-right:0.2rem;
  }
  .new-top-left img{
    width:100%;
  }
  .new-top-right{
    width:60%;
    font-size:0.14rem;
  }
  .new-top-title{
    color:#1F1F1F;
  }
  .new-top-price{
    color:#B4282D;
    margin:0.02rem 0;
  }
  .new-top-info{
    font-size: 0.13rem;
    color:#808080;
  }
  .new-content{
    display: flex;
    justify-content: space-between;
    flex-flow: row wrap;
    padding-bottom:0.15rem;
  }
  .new-item{
    width:31%;
    background-color: #F5F5F5;
    margin-top:0.1rem;
    border-radius: 0.05rem;
  }
  .new-item .item-img{
    width:98%;
    height:1rem;
    margin-bottom: 0.1rem;
  }
  .item-img img{
    width:100%;
  }
  .item-bottom{
    padding:0 0.07rem 0.2rem;
    line-height: 0.17rem;
  }
  .new-item .item-title{
    font-size: 0.12rem;
    color:#272727;
  }
  .item-title,.item-info{
    height:0.34rem;
    overflow: hidden;
  }
  .new-item .item-price{
    font-size: 0.12rem;
    color:#B4282D;
  }
  .split-hr{
    background-color:#DDDDDD;
    width:90%;
    height:1px;
    margin:0.1rem auto;
  }
  .new-item .item-info{
    font-size: 0.13rem;
    color:#7F7F7F;
  }
  /* 人气推荐 */
  .hot-pro{
    padding:0 0.15rem 0.15rem;
  }
  .hot-title{
    display: flex;
    justify-content: space-between;
    align-items: center;
    height:0.5rem;
  }
  .hot-title-left{
    font-size: 0.16rem;
    color:#333;
  }
  .hot-title-right{
    font-size: 0.14rem;
    color:#333;
  }
  .icon-xiangyoujiantou{
    font-size: 0.12rem;
  }
  .hot-top{
    display: flex;
    background-color: #FEF0DF;
    align-items: center;
    border-radius: 0.05rem;
    margin-bottom: 0.1rem;
  }
  .hot-top-left{
    width:1.4rem;
    height:1.4rem;
    margin-right:0.15rem;
    overflow:hidden;
  }
  .hot-top-left img{
    width:100%;
  }
  .hot-top-right{
    width:54%;
  }
  .hot-top-title{
    font-size: 0.14rem;
    color:#333;
  }
  .hot-top-info{
    font-size: 0.12rem;
    color:#7F7F7F;
  }
  .hot-top-price{
    color:#b4282d;
    font-size: 0.14rem;
  }
  .hot-item{
    width:31%;
  }
  .hot-item-top{
    position:relative;
    height:1.08rem;
    overflow:hidden;
    margin-bottom:0.07rem;
    background-color: #f5f5f5;
  }
  .hot-item-top img{
    width:100%;
  }
  .hot-item-top .select-color{
    position:absolute;
    top:0.05rem;
    left:0.05rem;
    width:0.16rem; 
    color:#b4a078;
    border:1px solid #b4a078;
    text-align:center;
    padding:0.03rem 0;
  }
  .select-color div{
    /*webkit不支持12px以下字体 */
    transform:scale(0.8);
    font-size:0.12rem;
    line-height:0.11rem;
  }
  .hot-item-title{
    font-size:0.12rem;
    line-height:0.17rem;
    color:#333;
    height:0.34rem;
    overflow:hidden;
  }
  .hot-item-title .hot-item-price{
    color: #b4282d;
  }
  .mark{
    display: inline-block;
    height:0.16rem;
    line-height: 0.16rem;
    color:#B4282D;
    border: 1px solid #B4282D;
    margin-right: 0.08rem;
  }
  .mark span{
    display: inline-block;
    font-size: 0.12rem;
    transform: scale(0.8);
    vertical-align: top;
  }
  /* footer */
  .footer{
    height:2rem;
  }
</style>