<template>
  <div class="app-details">
    <!-- 顶部轮播 -->
    <div class="app-swipe">
      <mt-swipe :auto="3000">
        <mt-swipe-item v-for="(item,index) in list" :key="index">
          <img :src="item.img_url" :alt="index"/>
          <div class="img-count">1/4</div>
        </mt-swipe-item>
      </mt-swipe>
    </div>
    <!-- 商品介绍 -->
    <div class="pro-intro">
      <div class="intro-item">
        <div class="intro-item-left">
          <img src="http://127.0.0.1:3030/img/pro-intro/p03-i03.jpg" alt="">
        </div>
        <div class="intro-item-right">
          <div>金属辅料</div>
          <div>光泽感强</div>
        </div>
      </div>
      <div class="intro-item">
        <div class="intro-item-left">
          <img src="http://127.0.0.1:3030/img/pro-intro/p03-i01.jpg" alt="">
        </div>
        <div class="intro-item-right">
          <div>金属辅料</div>
          <div>光泽感强</div>
        </div>
      </div>
      <div class="intro-item">
        <div class="intro-item-left">
          <img src="http://127.0.0.1:3030/img/pro-intro/p03-i02.jpg" alt="">
        </div>
        <div class="intro-item-right">
          <div>金属辅料</div>
          <div>光泽感强</div>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
export default {
  data() {
    return {
      list:[
        {id:1,img_url:"http://127.0.0.1:3030/img/details/p03-d03.jpg"},
        {id:2,img_url:"http://127.0.0.1:3030/img/details/p03-d01.jpg"},
        {id:3,img_url:"http://127.0.0.1:3030/img/details/p03-d02.jpg"},
        {id:4,img_url:"http://127.0.0.1:3030/img/details/p03-d04.jpg"}
      ],
    }
  },
}
</script>
<style lang="css" scoped>
   .app-swipe .mint-swipe{
    height:3.75rem;
    position: relative;
  }
  .app-swipe .mint-swipe img{
    width:100%;
    height: 100%;
  }
  .img-count{
    position:absolute;
    bottom:0.1rem;
    right:0.1rem;
    padding:0 0.06rem;
    background-color: #fff;
    font-size: 0.12rem;
    line-height: 0.18rem;
    color:#333;
    border-radius: 4px;
  }
  .pro-intro{
    height: 0.64rem;
    display: flex;
    align-items: center;
    margin:0 0.15rem;
  }
  .pro-intro .intro-item{
    width:33.3%;
    display: flex;
  }
  .intro-item-left{
    width:0.36rem;
    height:0.36rem;
    overflow: hidden;
    border-radius: 50%;
    margin-right: 0.05rem;
  }
  .intro-item-left img{
    width:100%;
    height:100%;
  }
  .intro-item-right{
    font-size: 0.14rem;
    color:#333;
    line-height: 0.16rem;
  }
  .intro-item-right div:first-child{
    margin-bottom: 0.08rem;
  }
</style>