<template>
  <div class="product-mark">
    <div class="mark"><span>三石福利价</span></div>
  </div>
</template>
<script>
export default {
  
}
</script>
<style lang="css" scoped>
  .mark{
    display: inline-block;
    height:0.16rem;
    line-height: 0.16rem;
    margin-right: 0.08rem;
    color: #B4282D;
    background: rgba(255,255,255,.9);
    border: 1px solid #B4282D;
  }
  .mark span{
    display: inline-block;
    font-size: 0.12rem;
    transform: scale(0.8);
    vertical-align: top;
    position: relative;
    top: -1px;
  }
</style>