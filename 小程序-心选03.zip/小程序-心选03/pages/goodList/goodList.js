// pages/goodList/goodList.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    //商品推荐列表
    showList: [],
    pageIndex: 0,  //当前页码
    pageSize: 6,   //页大小
    pageCount: 0    //总页数
  },
  //获取用户点击的商品id
  toDetail(e) {
    var pid = e.currentTarget.dataset.id;
    wx.navigateTo({
      url: "/pages/detail/detail?id="+pid,
    })
    //console.log(pid)
  },
  loadMore() {
    //获取页数 页码
    var pno = this.data.pageIndex;
    var pageSize = this.data.pageSize;
    var pageCount = this.data.pageCount;
    //判断当前是否为最后一页
    var hasMore = pno <= pageCount; //保存true 或false
    if (!hasMore) {
      wx.showToast({
        icon: 'none',
        title: '没有更多商品了',
      })
      setTimeout(function () {
        wx.hideToast();
      }, 1000);
      return
    };
    pno++;
    // 发送请求
    //console.log(pno, pageSize)
    wx.request({
      url: 'http://127.0.0.1:3030/showlist',
      data: { pno, pageSize },
      success: (res) => {
        //console.log(res)
        var rows = this.data.showList.concat(res.data.data);
        //console.log(rows)
        this.setData({
          showList: rows,
          pageIndex: pno,
          pageCount: res.data.pageCount
        });
        //显示加载动画
        wx.showToast({
          title: "加载更多好货...",
          icon:"loading"
        });
        setTimeout(function () {
          wx.hideToast();
        }, 1000)
      }
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.loadMore();
    //console.log(options)
    wx.setNavigationBarTitle({
      title:options.title
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    this.loadMore();
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})