// pages/cart/cart.js
const app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    //保存全局变量的购物车变量
    userCart:[],
    //用户已选商品总价
    total:0,
    //用户已选商品数量
    count:0,
    //保存用户已选商品
    selectIcon:[],
    //用户全选按钮
    allSelect:false,
    //用户点击起始x位置
    startX:0
  },
  //用户点击全选按钮
  userAllSel(){
    var allSelect = this.data.allSelect;
    var selectIcon = this.data.selectIcon;
    if (allSelect){
      allSelect=false;
      for (var item of selectIcon) {
        item.t = "circle"
      }
    }else{
      allSelect=true;
      for (var item of selectIcon){
        item.t="success"
      }
    }
    //console.log(this.data.selectIcon)
    this.seletedPro()
    this.setData({
      allSelect,
      selectIcon
    })
  },
  //用户点击商品左边选择框
  getIndex(e){
    //找到点击元素下标
    var index = e.target.dataset.tap;
    //console.log(index)
    //修改保存的属性
    var selectIcon = this.data.selectIcon;
    //判断是否被选中
    if (selectIcon[index].t != "success"){
      selectIcon[index].t="success";
    }else{
      selectIcon[index].t = "circle";
    }
    //console.log(selectIcon)
    this.setData({
      selectIcon
    })
    this.seletedPro()
  },
  //每一个商品的点击增加数量
  addCount(e){
    var value = e.target.dataset.value;
    var index = e.target.dataset.tap;
    var arr = this.data.selectIcon;
    value++;
    arr[index].value = value;
    //console.log(arr)
    this.setData({
      selectIcon:arr
    })
    this.seletedPro()
  },
  //每一个商品的点击减少数量
  reduceCount(e){
    var value = e.target.dataset.value;
    var index = e.target.dataset.tap;
    var arr = this.data.selectIcon;
    value--;
    if(value<=1){value = 1};
    arr[index].value = value;
    this.setData({
      selectIcon: arr
    });
    this.seletedPro()
  },
  //计算用户选择商品的总数
  seletedPro(){
    var selectIcon = this.data.selectIcon;
    //判断购物车是否为空
    if (selectIcon.length){
      var count = 0;
      var total = 0;
      var sum = 0;  //记录已选商品行数
      for (var item of selectIcon) {
        if (item.t == "success") {
          sum++;
          count += parseInt(item.value);
          total += item.value * item.newPrice;
        }
      };
      //如果当前选择的商品全部选中
      if (sum == selectIcon.length) {
        this.setData({ allSelect: true })
      } else {
        this.setData({ allSelect: false })
      };
      this.setData({
        count,
        total
      })
    }else{
      this.setData({
        allSelect: false,
        count : 0,
        total : 0
      })
    }
    
  },
  //下单
  toBuy(){
    var count = this.data.count;
    var total = this.data.total;
    if(count){
      wx.showModal({
        title: '确认下单？',
        content: '已选择：' + count + '件商品，总价：' + total + '.00元',
        success: (res) => {
          if (res.confirm) {
            //用户确认下单，删除购物车中选中的商品
            var selectIcon1 = this.data.selectIcon;
            var userCart1 = this.data.userCart;
            var globalCart1 = app.globalData.userCart;
            var selectIcon = [];
            var userCart = [];
            var globalCart = [];
            for (var i = 0; i < selectIcon1.length;i++ ){
              if (selectIcon1[i].t != "success"){
                selectIcon.push(selectIcon1[i]);
                userCart.push(userCart1[i]);
                globalCart.push(globalCart1[i]);
              }
            }
            //修改全局变量
            app.globalData.userCart = globalCart;
            this.setData({
              selectIcon,
              userCart,
              count:0,
              total:0
            })  
            wx.showToast({
              title: '下单成功！',
              icon:'none'
            });
            setTimeout(function () {
              wx.hideToast();
            }, 1500)
          }
        }
      })
    }else{
      wx.showToast({
        title: '请选择商品',
        icon: 'none'
      });
      setTimeout(function () {
        wx.hideToast();
      }, 1500)
    }
  },
  touchmove(e){
    console.log(e)
    var index = e.target.dataset.index;
    this.setData({
      isDelete:true
    })
    console.log(123) 
  },
  //用户左滑动显示删除商品按钮，或向右滑动隐藏删除商品按钮
  touchStart(e){
    //console.log(e)
    if(e.touches.length == 1){
      //获取手指起始点击x位置
      this.setData({
        startX:e.touches[0].clientX
      })
    }
  },
  touchEnd(e){
    //console.log(e)
    if(e.changedTouches.length == 1){
      var index = e.currentTarget.dataset.index;
      var selectIcon = this.data.selectIcon;
      var endX = e.changedTouches[0].clientX;
      //console.log(endX)
      var disX = this.data.startX - endX;
      //console.log(disX)
      var isDelete = selectIcon[index].isDelete;
      if (!isDelete){
        if (disX > 35) { isDelete = true };
      }else{
        if(disX < -35){isDelete = false}
      }
      selectIcon[index].isDelete = isDelete;
      this.setData({
        selectIcon
      })
    }
  },
  //用户点击删除按钮
  deletePro(e){
    var index = e.target.dataset.index;
    var selectIcon = this.data.selectIcon;
    var userCart = this.data.userCart;
    selectIcon.splice(index,1);
    userCart.splice(index,1);
    this.setData({
      selectIcon,
      userCart
    })
    this.seletedPro();
    //修改全局变量
    app.globalData.userCart.splice(index,1);
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    //把全局变量提取出来
    var userCart = app.globalData.userCart; 
    //console.log(userCart)
    //给点击的选择框type属性创建一个数组保存
    var selectIcon=[];
    for(var item of userCart){
      var obj = { t: "circle",isDelete:false};
      obj.value = item.value;
      obj.newPrice = item.newPrice;
      selectIcon.push(obj)
    }
    this.setData({
      userCart,
      selectIcon
    });
    //console.log(this.data.selectIcon)
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function(){

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
    //把用户修改的值赋给全局变量
    if (!this.data.userCart.length){
      app.globalData.userCart=[];
    }else{
      var arr = this.data.selectIcon;
      console.log(arr)
      console.log(app.globalData.userCart)
      for (var i = 0; i < app.globalData.userCart.length; i++) {
        app.globalData.userCart[i].value = arr[i].value
      }
    }
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})