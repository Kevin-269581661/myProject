// pages/sort/sort.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    scrollTop:0,  //右侧滚动条滚动距离
    currentTap: 0,  //左侧当前点击对象index
    id:0,          //左侧类目第一行的id
    leftList:[],  //左侧类名列表
    rightList: {}  //右侧商品列表
  },
  //封装请求函数 id为左侧类目传递的参数
  req(id) {
    wx.request({
      url: 'http://127.0.0.1:3030/rightlist',
      data: {id},
      success: (res) => {
        var obj = res.data;
        //console.log(obj)
        this.setData({
          rightList: obj
        })
      }
    })
  },
  //用户点击左侧类目栏
  handle(e){
    var tap = e.target.dataset.tap; //获取当前点击对象index
    var id = e.target.dataset.id; 
    this.setData({
      currentTap: tap, //当前点击对象index
      scrollTop: 0,  //切换类目右侧回到顶部
      id: id    //当前点击对象id
    });
    this.req(id);
    console.log(this.data.rightList)
  },
  //获取用户点击的商品id
  toDetail(e) {
    var pid = e.currentTarget.dataset.id;
    wx.navigateTo({
      url: "/pages/detail/detail?id=" + pid,
    })
    //console.log(pid)
  },
  
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    //加载左侧数据
    wx.request({
      url: 'http://127.0.0.1:3030/leftlist',
      success: (res) => {
        var arr = res.data;
        var id = arr[0].id //获取第一行类目id
        //console.log(arr)
        this.setData({
          leftList: arr,
          id:id
        })
      }
    })
   },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    var id = this.data.id;
    console.log(id)
    this.req(id);
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})