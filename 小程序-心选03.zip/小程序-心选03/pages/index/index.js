//index.js
//获取应用实例
const app = getApp()

Page({

  /**
   * 页面的初始数据
   */
  data: {
    //轮播图列表
    bannerList:[],
    // 首页九宫格分类 
    sortList:[],
    // 楼层展示列表
    hotList:[],
    //商品推荐列表
    showList:[],
    pageIndex:0,  //当前页码
    pageSize: 6,   //页大小
    pageCount:0    //总页数
  },
  //分页加载商品推荐数据 在上拉触顶事件中调用
  loadMore(){
    //获取页数 页码
    var pno = this.data.pageIndex;
    var pageSize = this.data.pageSize;
    var pageCount = this.data.pageCount;
    //判断当前是否为最后一页
    var hasMore = pno <=  pageCount; //保存true 或false
    if (!hasMore){ 
      wx.showToast({
        icon:'none',
        title: '没有更多商品了',
      })
      setTimeout(function () {
        wx.hideToast();
      }, 1000);
      return 
    };
    pno++;
    // 发送请求
    //console.log(pno, pageSize)
    wx.request({
      url: 'http://127.0.0.1:3030/showlist',
      data:{pno,pageSize},
      success:(res)=>{
        //console.log(res)
        var rows = this.data.showList.concat(res.data.data);
        //console.log(rows)
        this.setData({
          showList:rows,
          pageIndex:pno,
          pageCount:res.data.pageCount
        });
        //显示加载动画
        wx.showLoading({
          title:"加载更多好货..."
        });
        setTimeout(function(){
          wx.hideLoading();
        },1000)
      }
    })
  },
  //用户点击九宫格跳到对应商品列表
  toGoodList(e){
    var title = e.target.dataset.title;
    //console.log(title)
    wx.navigateTo({
      url: "/pages/goodList/goodList?title="+title
    })
  },
  //获取用户点击的商品id
  toDetail(e){
    var pid = e.currentTarget.dataset.id;
    wx.navigateTo({
      url: "/pages/detail/detail?id=" + pid,
    })
    //console.log(pid)
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options){
    
    //请求轮播图列表
    wx.request({
      url: 'http://127.0.0.1:3030/bannerlist',
      success:(res)=>{
        //console.log(res)
        this.setData({
          bannerList: res.data
        })
      }
    });
    //请求分类列表
    wx.request({
      url: 'http://127.0.0.1:3030/sortlist',
      success: (res) => {
        //console.log(res)
        this.setData({
          sortList: res.data
        })
      }
    });
    //请求楼层列表
    wx.request({
      url: 'http://127.0.0.1:3030/floorlist',
      success: (res) => {
        //console.log(res)
        this.setData({
          hotList: res.data
        })
      }
    });
    this.loadMore();
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
    
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
    
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    this.loadMore();
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
    
  }
})
