// pages/person/person.js
const app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    avatarUrl: 'http://127.0.0.1:3030/img/person/person01.png',
    userInfo: {},
    userName:'微信登录',
    logged:false
  },
  //获取用户登录信息
  onGetUserInfo: function () {
    wx.getSetting({
      success: res => {
        if (res.authSetting['scope.userInfo']) {
          // 已经授权，可以直接调用 getUserInfo 获取头像昵称，不会弹框
          wx.getUserInfo({
            success: res =>{
              var logged = this.data.logged;
              logged = true;
              var userInfo = res.userInfo;
              var avatarUrl = res.userInfo.avatarUrl;
              var userName = res.userInfo.nickName;
              app.globalData.userInfo = userInfo;
              app.globalData.logged = true;  
              this.setData({
                userInfo,
                avatarUrl,
                userName,
                logged
              })
            }
          })
        }
      }
    })
  },
  //上传头像图片
  changeAvator(){
    wx.chooseImage({
      sount:1,  //选择单张图片
      sizeType:["compressed"], //压缩原图
      sourceType:["camera","album"], //从相机或相册中选取
      success: function(res){
        //console.log(res.tempFilePaths[0])
        //给用户提示
        wx.showToast({
          title:'正在上传中...',
          icon:'loading',
        })
        setTimeout(function(){
          wx.hideToast();
        },1500)
        //上传图片
        wx.uploadFile({
          url:'http://127.0.0.1:3030/upload',
          filePath:res.tempFilePaths[0],//图片本地路径
          name:'mypic', //图片name值
          header:{  //指定头部
            "Content-Type":"multipart/form-data"
          },
          success:(res)=>{
            console.log(res)
          },
          fail:function(){
            wx.showModal({
              title:"错误提示",
              content:"系统正在升级中，请5s后再试！",
              showCancel:false,
              success:function(){}
            })
          }
        })
      },
    })
  },
  logout(){
    
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})