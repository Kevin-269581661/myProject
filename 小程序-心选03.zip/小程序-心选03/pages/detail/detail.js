// pages/detail/detail.js
const app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    //控制选择规格的弹窗状态是否为弹出状态
    addShow:false,
    //当前的商品对象
    product:{},
    //控制用户选择规格是否已选择
    userSelected:null,
    //用户选择的商品数量
    value:1,
    size:"",
    //用户选择的商品属性
    userPro:{
      id:"",
      img_url:"",
      title:"",
      newPrice:"",
      size:"",
      value:"",
      mark:""
    }
    
  },
  //点击x关闭弹窗
  close(){
    this.setData({
      addShow:false
    })
  },
  //弹出规格窗
  open(){
    this.setData({
      addShow:true
    })
  },
  // 点击添加购物车弹出窗口
  addCart(){
    //判断弹出状态
    if (!this.data.addShow){
      this.open();
    }else{
      var userPro = this.data.userPro;
      //判断用户是否选择了规格
      if (this.data.size){
        //判断用户是否已登录
        if(app.globalData.logged){
          userPro.value = this.data.value;
          userPro.size = this.data.size;
          this.setData({
            userPro
          });
          //console.log(userPro)
          //添加到全局变量（购物车）
          var arr = app.globalData.userCart;
          //判断全局变量是否为空
          if (arr.length) {
            //console.log(arr)
            //找出全局变量与用现在选择的商品是否相同，规格也相同
            //如果有，把此次选择数量添加到全局的商品
            var isExist = false;
            for (var item of arr) {
              if (userPro.id == item.id && userPro.size == item.size) {
                item.value += userPro.value;
                isExist = true;
              }
            }
            if (!isExist) {
              app.globalData.userCart.unshift(userPro)
            } else {
              app.globalData.userCart = arr;
            }
          } else {
            app.globalData.userCart.unshift(userPro)
          }
          //console.log(app.globalData.userCart)
          wx.showToast({
            title: '添加购物车成功',
            icon: "none"
          });
          setTimeout(function () {
            wx.hideToast();
          }, 15000)
        }else{
          wx.showToast({
            title: '请先登录',
            icon:'none'
          })
          setTimeout(function(){
            wx.hideToast();
          },1500)
        }
        
      }else{
        wx.showToast({
          title: '请添加商品属性',
          icon:"none"
        });
        setTimeout(function(){
          wx.hideToast();
        },15000)
      }
    } 
  },
  //用户点击购买
  toBuy(){
    if (!this.data.addShow) {
      this.open();
    } else {
      if (!this.data.size) {
        wx.showToast({
          title: '请添加商品属性',
          icon: "none"
        });
        setTimeout(function () {
          wx.hideToast();
        }, 15000)
      }else{
        //判断用户是否已登录
        if (app.globalData.logged) {
          wx.showModal({
            title: "温馨提示",
            content: "系统正在升级中，请稍后再试！",
            showCancel: false
          })
        }else{
          wx.showToast({
            title: '请先登录',
            icon: 'none'
          })
          setTimeout(function () {
            wx.hideToast();
          }, 1500)
        }
        
      }
      
    }
  },
  //回到首页
  toHome(){
    wx.reLaunch({
      url: "/pages/index/index"
    })
  },
  //回到购物车
  toCart(){
    wx.reLaunch({
      url: "/pages/cart/cart",
    })
  },
  //添加商品规格
  getSize(e){
    var size = e.currentTarget.dataset.size;
    var tap = e.currentTarget.dataset.tap;
    //console.log(size)
    this.setData({
      userSelected: tap,
      size
    })
  },
  //选择加 、减 商品数量
  addCount(){
    var sum = this.data.value;
    sum++;
    this.setData({
      value:sum
    })
  },
  reduceCount(){
    var sum = this.data.value;
    sum--;
    if(sum<=1){sum = 1};
    this.setData({
      value: sum
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    //console.log(options.id)
    var id = options.id;
    wx.request({
      url: 'http://127.0.0.1:3030/productdetail',
      data:{id},
      success:(res)=>{
        //console.log(res.data)
        var userPro = this.data.userPro;
        userPro.id = res.data.id;
        userPro.img_url = res.data.img_url;
        userPro.title = res.data.title;
        userPro.mark = res.data.mark;
        userPro.newPrice = res.data.newPrice;
        this.setData({
          product:res.data,
          userPro
        })
      }
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})